# <h1 align="center">  MEAL  PLANNER ( MP )

# <h1 align="center">  GCS - Equipo 2
  
# Descripción
---
Sistema web que personaliza plan de comidas de forma semanal según su dieta, hábitos alimenticios, preferencias y cualquier intolerancia o alergia alimentaria con el objetivo de facilitar la organización de sus alimentos en un calendario personalizado.
  
# Curso
---
Gestión de la configuración del Software.

# Docente
---
 Dra. Lenis Rossi Wong Portillo.

# Coordinadora
---
- Torres Talaverano, Luz Elena.
  
# Integrantes
---
- Arango Quispe, Esmeralda - 19200300
- Blas Ruiz, Luis Aaron - 19200069
- Huarhuachi Ortega, Andrea Mariana - 19200267  
- Palacios Barrutia, Jeanpiere Julian - 19200274  
- Rojas Villanueva, Paula Elianne - 19200266
- Torres Berlanga, Christian - 19200291
- Torres Talaverano, Luz Elena - 19200294


  

