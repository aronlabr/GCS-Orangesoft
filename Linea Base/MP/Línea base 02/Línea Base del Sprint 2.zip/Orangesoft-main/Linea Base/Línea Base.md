Linea de Base
