<section class="footer-container">
  <section class="footer-first">
    <div class="footer-logo">
      <i class="footer-icon"></i>
      <h1>MEAL PLANNER</h1>
    </div>
    <div class="footer-us">
      <h3>Nosotros</h3>
      <a href="#">¿Quiénes somos?</a>
      <a href="#">Misión y Visión</a>
      <a href="#">Contáctanos</a>
    </div>
    <div class="footer-social">
      <h3>Redes Sociales</h3>
      <div class="social-item"><i class="face-icon"></i><a href="#">Facebook</a></div>
      <div class="social-item"><i class="twit-icon"></i><a href="#">Twitter</a></div>
      <div class="social-item"><i class="inst-icon"></i><a href="#">Instagram</a></div>
    </div>
  </section>
  <hr>
  <section class="footer-second">
    <div style="text-align: center;"><a href="#">Términos y Condiciones</a></div>
    <div><a href="#">Avisos Legales</a></div>
    <div><a href="#">Política de Privacidad</a></div>
  </section>
</section>